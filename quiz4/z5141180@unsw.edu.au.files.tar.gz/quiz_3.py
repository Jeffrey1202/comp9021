# Randomly generates a grid with 0s and 1s, whose dimension is controlled by user input,
# as well as the density of 1s in the grid, and finds out, for a given direction being
# one of N, E, S or W (for North, East, South or West) and for a given size greater than 1,
# the number of triangles pointing in that direction, and of that size.
#
# Triangles pointing North:
# - of size 2:
#   1
# 1 1 1
# - of size 3:
#     1
#   1 1 1
# 1 1 1 1 1
#
# Triangles pointing East:
# - of size 2:
# 1
# 1 1
# 1
# - of size 3:
# 1
# 1 1
# 1 1 1 
# 1 1
# 1
#
# Triangles pointing South:
# - of size 2:
# 1 1 1
#   1
# - of size 3:
# 1 1 1 1 1
#   1 1 1
#     1
#
# Triangles pointing West:
# - of size 2:
#   1
# 1 1
#   1
# - of size 3:
#     1
#   1 1
# 1 1 1 
#   1 1
#     1
#
# The output lists, for every direction and for every size, the number of triangles
# pointing in that direction and of that size, provided there is at least one such triangle.
# For a given direction, the possble sizes are listed from largest to smallest.
#
# We do not count triangles that are truncations of larger triangles, that is, obtained
# from the latter by ignoring at least one layer, starting from the base.
#
# Written by *** and Eric Martin for COMP9021


from random import seed, randint
import sys
from collections import defaultdict


def display_grid():
    for i in range(len(grid)):
        print('   ', ' '.join(str(int(grid[i][j] != 0)) for j in range(len(grid))))

record = []
record1=[]
record2=[]
def triangles_in_grid():
    gridW = turn(grid)
    gridS = turn(gridW)
    gridE = turn(gridS)

    dit1=find_point(grid, 'N')
    dit2=find_point(gridW, 'W')
    dit3=find_point(gridS, 'S')
    dit4=find_point(gridE, 'E')
    dit=dict(dit1,**dit2,**dit3,**dit4)
    return dit

def find_point(grid,direction):
    recordN=[]
    global record
    record=[]
    for size in range((len(grid) + 1) // 2, 1, -1):
        nb_of_triangles = 0
        for i in range(len(grid) - size + 1):
            for j in range(size - 1, dim - size + 1):
                if grid[i][j] and [i, j] not in record:
                    nb_of_triangles = triangle(i, j, size, nb_of_triangles, grid)
        if nb_of_triangles != 0:
            recordN.append([size, nb_of_triangles])
    if recordN==[]:
        return {}
    else:
        return {direction:recordN}

def triangle(i, j, size, nb_of_triangles,grid):

    for x in range(i + 1, i + size):
        for y in range(j - x + i, j + x - i + 1):
            if not grid[x][y]:
                return nb_of_triangles
    record.append([i, j])
    nb_of_triangles += 1
    return nb_of_triangles


def turn(list):
    b = [[0 for i in range(len(list))] for j in range(len(list))]
    for i in range(len(list)):
        for j in range(len(list)):
            b[len(list) - 1 - j][len(list) - 1 - i] = list[i][len(list) - 1 - j]
    return b
	
				
    # Replace return {} above with your code

# Possibly define other functions
	

try:
    arg_for_seed, density, dim = input('Enter three nonnegative integers: ').split()
except ValueError:
    print('Incorrect input, giving up.')
    sys.exit()
try:
    arg_for_seed, density, dim = int(arg_for_seed), int(density), int(dim)
    if arg_for_seed < 0 or density < 0 or dim < 0:
        raise ValueError
except ValueError:
    print('Incorrect input, giving up.')
    sys.exit()
seed(arg_for_seed)
grid = [[randint(0, density) for _ in range(dim)] for _ in range(dim)]
print('Here is the grid that has been generated:')
display_grid()
# A dictionary whose keys are amongst 'N', 'E', 'S' and 'W',
# and whose values are pairs of the form (size, number_of_triangles_of_that_size),
# ordered from largest to smallest size.
triangles = triangles_in_grid()
for direction in sorted(triangles, key = lambda x: 'NESW'.index(x)):
    print(f'\nFor triangles pointing {direction}, we have:')
    for size, nb_of_triangles in triangles[direction]:
        triangle_or_triangles = 'triangle' if nb_of_triangles == 1 else 'triangles'
        print(f'     {nb_of_triangles} {triangle_or_triangles} of size {size}')
