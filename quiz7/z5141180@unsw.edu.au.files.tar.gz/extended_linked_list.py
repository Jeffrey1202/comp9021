# Written by YIZHENG YING for COMP9021

from linked_list_adt import *


class ExtendedLinkedList(LinkedList):
    def __init__(self, L=None):
        super().__init__(L)

    def rearrange(self):
        length=self.__len__()
        if length<2:
            return
        x=(length+1)//2-1
        head=self.head
        smallest_index=0
        smallest=head.value

        for _ in range(length-1):
            if head.next_node.value<smallest:
                smallest=head.next_node.value
                smallest_index=self.index_of_value(smallest)
            head=head.next_node		
        pre_index=smallest_index-1
        #print('pre_index',pre_index)
        head.next_node=self.head
        #print('head',head.next_node.value)
        head=self.head
        #print('head1', head.value)
        for _ in range(pre_index):
            head=head.next_node
        pre_node=head
        self.head=pre_node.next_node
        current_node=pre_node.next_node

        ##print(current_node.value,self.head.value,pre_node.next_node.value)
        ##5 5 5

        for _ in range(x):
            next_node_no2=current_node.next_node
            #print('current_node.next_node',current_node.next_node.value)
            current_node.next_node=pre_node
            #print(pre_node.value)
            current_node=next_node_no2.next_node
            #print(next_node_no2.next_node.value)
            pre_node.next_node=current_node
            #print(current_node.value)
            pre_node=next_node_no2
            #print(next_node_no2.value)
        current_node.next_node=pre_node
        #print('pre_node',pre_node.value)
        pre_node.next_node=None
    
    
    
